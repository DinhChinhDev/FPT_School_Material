﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoDataGrid
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += DemoDataGrid_Loaded;
        }

        private void DemoDataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            List<Car> cars = new List<Car>
            { 
                new Car{ CarName = "A6", Color = "White", Brand = "Audi" },
                new Car{ CarName = "Lexus", Color = "Black", Brand = "Toyota" },
                new Car{ CarName = "Ford Ranger Raptor", Color = "White", Brand = "Ford" }
            };
            dgCarList.ItemsSource = cars;
        }
    }
}